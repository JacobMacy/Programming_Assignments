import unittest

from my_sum import sum


class TestSum(unittest.TestCase):
    def test_list_int(self):
        """
        Test that it can sum a list of integers
        """
        data = [1, 2, 3]
        result = sum(data)
        self.assertEqual(result, 6)


if __name__ == "__main__":
    unittest.main()

"""
After running this test, the result 'Ran 1 test in 0.000s' returned
as well as the word 'OK'. This shows that the sum function correctly
added the numbers together and returned 6, as was expected.
"""