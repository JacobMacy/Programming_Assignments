from django.shortcuts import render


def student_form(request):
    if request.method == "POST":
        name = request.POST.get("student_name", "").strip()
        student_id = request.POST.get("student_id", "").strip()

        if not name or not student_id:
            return render(request, "students/form.html", {
                "error": "Student Name and Student ID cannot be blank."
            })

        student = {
            "name": name,
            "student_id": student_id,
            "major": request.POST.get("major", ""),
            "standing": request.POST.get("standing", ""),
            "languages": request.POST.getlist("languages"),
            "year": request.POST.get("year", ""),
            "comments": request.POST.get("comments", ""),
        }
        return render(request, "students/results.html", {"student": student})

    return render(request, "students/form.html")
