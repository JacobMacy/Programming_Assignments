# Student Information

1. Extract the ZIP.
2. Open the Student_Information folder in VS Code.
3. Open a terminal and run:

```powershell
py -m pip install -r requirements.txt
py manage.py runserver
```

4. Open http://127.0.0.1:8000/ in your browser.

## Main files
- students/views.py checks the name and ID, collects input, and displays results.
- students/urls.py connects the web address to the view.
- students/templates/students/form.html contains the HTML form.
- students/templates/students/results.html shows the summary.

Clicking Submit sends a POST request. The view responds to that event.
If the name or ID is blank, it shows an error. Otherwise, it displays the
results using a different HTML template. Information is not saved.
